easyIT Enterprise – Projektsicherung
======================================

Projekt: muster_csv
Datenbank: easyit_muster_csv
Erstellt: 2026-08-26T09:02:20+00:00

Inhalt:
- project.json: Enterprise-Projektmetadaten
- database.sql: physisches Projektdatenbankschema und Datensätze
- manifest.json: Sicherungsmanifest und Statistik

Wiederherstellung:
1. database.sql auf dem gewünschten MySQL/MariaDB-Server einspielen.
2. Das Projekt im Enterprise Manager als vorhandenes Projekt registrieren.
3. Dabei den Datenbanknamen aus project.json verwenden.

Hinweis: Das globale easyIT-Programm selbst ist nicht Bestandteil dieser Projektsicherung.
