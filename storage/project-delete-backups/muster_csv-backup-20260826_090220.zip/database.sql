-- easyIT Enterprise project backup
-- Database: easyit_muster_csv
-- Generated: 2026-08-26T09:02:20+00:00

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE IF NOT EXISTS `easyit_muster_csv` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `easyit_muster_csv`;

-- Table data_sources
DROP TABLE IF EXISTS `data_sources`;
CREATE TABLE `data_sources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `driver` varchar(30) NOT NULL,
  `config_json` longtext NOT NULL,
  `secret_ciphertext` longtext DEFAULT NULL,
  `secret_nonce` varchar(255) DEFAULT NULL,
  `secret_tag` varchar(255) DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_test_status` varchar(20) NOT NULL DEFAULT 'unknown',
  `last_test_message` text DEFAULT NULL,
  `last_test_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_data_source_name` (`name`),
  KEY `idx_data_sources_driver` (`driver`),
  KEY `idx_data_sources_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_fields
DROP TABLE IF EXISTS `dataform_fields`;
CREATE TABLE `dataform_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `name` varchar(160) NOT NULL,
  `label` varchar(190) NOT NULL,
  `field_type` varchar(80) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `configuration_json` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_form_field` (`dataform_id`,`name`),
  CONSTRAINT `fk_field_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_managed_tables
DROP TABLE IF EXISTS `dataform_managed_tables`;
CREATE TABLE `dataform_managed_tables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_managed_table` (`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_table_bindings
DROP TABLE IF EXISTS `dataform_table_bindings`;
CREATE TABLE `dataform_table_bindings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `source_kind` varchar(30) NOT NULL DEFAULT 'system',
  `source_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(64) NOT NULL,
  `binding_mode` varchar(30) NOT NULL DEFAULT 'schema',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_table_binding_form` (`dataform_id`),
  UNIQUE KEY `uq_dataform_table_binding_source` (`source_kind`,`source_id`,`table_name`),
  CONSTRAINT `fk_dataform_table_binding_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataforms
DROP TABLE IF EXISTS `dataforms`;
CREATE TABLE `dataforms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'draft',
  `table_save_mode` varchar(20) NOT NULL DEFAULT 'manual',
  `show_save_success` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(190) NOT NULL,
  `checksum` char(64) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;






INSERT INTO `migrations` (`id`, `migration`, `checksum`, `executed_at`) VALUES
(1, '001_migrations.php', 'ad096de26556296667dd203af6823bdd43355bafd422741f8f15f9ee54c284c4', '2026-08-26 11:01:45'),
(3, '002_dataforms.php', '41443b71f9ac7eed71db34e3cdb7cdfef2a1d459b7a4463b269da88733a96b81', '2026-08-26 11:01:45'),
(4, '003_data_sources.php', '6cc3abc8dfb24d66ceb53bb34763fbdc424b86803628ce163a43334e91a5ea6b', '2026-08-26 11:01:45'),
(5, '004_table_workspace.php', 'a15c693c079263ed84b00549fb6d11a850bebceaf9254e44aa89ef8eaf054fe8', '2026-08-26 11:01:45'),
(6, '005_dataform_table_bindings.php', '43544f5b3792a0a472ae69d6efe00090536680abd58e3de148e77e19ee9a3d1d', '2026-08-26 11:01:45');

SET FOREIGN_KEY_CHECKS=1;
