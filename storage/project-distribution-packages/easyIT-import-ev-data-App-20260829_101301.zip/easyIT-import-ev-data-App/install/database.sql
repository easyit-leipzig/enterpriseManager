-- easyIT Enterprise project backup
-- Database: easyit_testprojekt_64
-- Generated: 2026-08-29T10:13:01+00:00

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';


-- Table data_sources
DROP TABLE IF EXISTS `data_sources`;
CREATE TABLE `data_sources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `driver` varchar(30) NOT NULL,
  `config_json` longtext NOT NULL,
  `secret_ciphertext` longtext DEFAULT NULL,
  `secret_nonce` varchar(255) DEFAULT NULL,
  `secret_tag` varchar(255) DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_test_status` varchar(20) NOT NULL DEFAULT 'unknown',
  `last_test_message` text DEFAULT NULL,
  `last_test_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_data_source_name` (`name`),
  KEY `idx_data_sources_driver` (`driver`),
  KEY `idx_data_sources_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_behaviors
DROP TABLE IF EXISTS `dataform_behaviors`;
CREATE TABLE `dataform_behaviors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `event_key` varchar(60) NOT NULL,
  `name` varchar(190) NOT NULL,
  `action_type` varchar(60) NOT NULL DEFAULT 'placeholder',
  `configuration_json` longtext DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_behavior_dataform` (`dataform_id`),
  KEY `idx_behavior_event` (`event_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_fields
DROP TABLE IF EXISTS `dataform_fields`;
CREATE TABLE `dataform_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `name` varchar(160) NOT NULL,
  `label` varchar(190) NOT NULL,
  `field_type` varchar(80) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `configuration_json` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_form_field` (`dataform_id`,`name`),
  CONSTRAINT `fk_field_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_import_profiles
DROP TABLE IF EXISTS `dataform_import_profiles`;
CREATE TABLE `dataform_import_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `mapping_json` longtext NOT NULL,
  `duplicate_fields_json` longtext NOT NULL,
  `duplicate_action` varchar(20) NOT NULL DEFAULT 'skip',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_import_profile_name` (`dataform_id`,`user_id`,`name`),
  KEY `idx_import_profiles_form_user` (`dataform_id`,`user_id`),
  CONSTRAINT `fk_import_profiles_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_layout_nodes
DROP TABLE IF EXISTS `dataform_layout_nodes`;
CREATE TABLE `dataform_layout_nodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `node_type` varchar(40) NOT NULL,
  `title` varchar(190) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 10,
  `configuration_json` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_layout_dataform` (`dataform_id`),
  KEY `idx_layout_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_list_settings
DROP TABLE IF EXISTS `dataform_list_settings`;
CREATE TABLE `dataform_list_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `visible_columns_json` longtext NOT NULL,
  `per_page` int(10) unsigned NOT NULL DEFAULT 20,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_list_settings` (`dataform_id`,`user_id`),
  CONSTRAINT `fk_list_settings_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_managed_tables
DROP TABLE IF EXISTS `dataform_managed_tables`;
CREATE TABLE `dataform_managed_tables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_managed_table` (`table_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_queries
DROP TABLE IF EXISTS `dataform_queries`;
CREATE TABLE `dataform_queries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `name` varchar(190) NOT NULL,
  `description` text DEFAULT NULL,
  `definition_json` longtext NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_query_name` (`dataform_id`,`name`),
  KEY `idx_dataform_queries_form` (`dataform_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_records
DROP TABLE IF EXISTS `dataform_records`;
CREATE TABLE `dataform_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `data_json` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dataform_records_form` (`dataform_id`),
  CONSTRAINT `fk_dataform_records_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_relations
DROP TABLE IF EXISTS `dataform_relations`;
CREATE TABLE `dataform_relations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `relation_type` varchar(10) NOT NULL,
  `source_dataform_id` bigint(20) unsigned NOT NULL,
  `source_field_id` bigint(20) unsigned DEFAULT NULL,
  `target_dataform_id` bigint(20) unsigned NOT NULL,
  `target_display_field_id` bigint(20) unsigned DEFAULT NULL,
  `junction_name` varchar(190) DEFAULT NULL,
  `lookup_field_id` bigint(20) unsigned DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `configuration_json` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_relation_name` (`name`),
  KEY `idx_relation_source` (`source_dataform_id`),
  KEY `idx_relation_target` (`target_dataform_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_saved_filters
DROP TABLE IF EXISTS `dataform_saved_filters`;
CREATE TABLE `dataform_saved_filters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `query_json` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_saved_filter_name` (`dataform_id`,`user_id`,`name`),
  KEY `idx_saved_filters_form_user` (`dataform_id`,`user_id`),
  CONSTRAINT `fk_saved_filters_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_table_bindings
DROP TABLE IF EXISTS `dataform_table_bindings`;
CREATE TABLE `dataform_table_bindings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `source_kind` varchar(30) NOT NULL DEFAULT 'system',
  `source_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(64) NOT NULL,
  `binding_mode` varchar(30) NOT NULL DEFAULT 'schema',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_table_binding_form` (`dataform_id`),
  UNIQUE KEY `uq_dataform_table_binding_source` (`source_kind`,`source_id`,`table_name`),
  CONSTRAINT `fk_dataform_table_binding_form` FOREIGN KEY (`dataform_id`) REFERENCES `dataforms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataform_versions
DROP TABLE IF EXISTS `dataform_versions`;
CREATE TABLE `dataform_versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dataform_id` bigint(20) unsigned NOT NULL,
  `version_label` varchar(40) NOT NULL,
  `change_note` text DEFAULT NULL,
  `snapshot_json` longtext NOT NULL,
  `created_by` varchar(190) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dataform_version` (`dataform_id`,`version_label`),
  KEY `idx_version_dataform` (`dataform_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table dataforms
DROP TABLE IF EXISTS `dataforms`;
CREATE TABLE `dataforms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'draft',
  `table_save_mode` varchar(20) NOT NULL DEFAULT 'manual',
  `show_save_success` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table ed_ev
DROP TABLE IF EXISTS `ed_ev`;
CREATE TABLE `ed_ev` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_df_ed_ev_date_time_d74b94c957` (`date_time`)
) ENGINE=InnoDB AUTO_INCREMENT=9221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table ed_ev_info
DROP TABLE IF EXISTS `ed_ev_info`;
CREATE TABLE `ed_ev_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `to_ev_id` int(10) unsigned DEFAULT NULL,
  `typ` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `bemerkung` varchar(512) DEFAULT NULL,
  `from_person` int(11) NOT NULL,
  `to_person` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_df_ed_ev_info_to_ev_id_3d04cc7a15` (`to_ev_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9326 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table ed_ev_person
DROP TABLE IF EXISTS `ed_ev_person`;
CREATE TABLE `ed_ev_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `saturation` int(1) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_df_ed_ev_person_email_4259d1f442` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table ed_ev_type
DROP TABLE IF EXISTS `ed_ev_type`;
CREATE TABLE `ed_ev_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ev_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_df_ed_ev_type_ev_type_dfaf3312f0` (`ev_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(190) NOT NULL,
  `checksum` char(64) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table project_package_history
DROP TABLE IF EXISTS `project_package_history`;
CREATE TABLE `project_package_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `package_id` varchar(64) NOT NULL,
  `project_name` varchar(190) NOT NULL,
  `package_name` varchar(190) DEFAULT NULL,
  `package_version` varchar(32) NOT NULL,
  `action_name` varchar(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `sha256` char(64) NOT NULL,
  `status` varchar(20) NOT NULL,
  `details_json` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pph_project` (`project_name`),
  KEY `idx_pph_action` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



INSERT INTO `dataform_fields` (`id`, `dataform_id`, `name`, `label`, `field_type`, `position`, `is_required`, `configuration_json`, `created_at`) VALUES
(4, 4, 'typ', 'Typ', 'number', 20, 0, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"typ\",\"sql_type\":\"int(11)\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-16 12:14:01'),
(5, 4, 'date_time', 'Date Time', 'datetime', 30, 0, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"date_time\",\"sql_type\":\"datetime\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-16 12:14:01'),
(6, 4, 'bemerkung', 'Bemerkung', 'text', 40, 0, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"bemerkung\",\"sql_type\":\"varchar(512)\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-16 12:14:01'),
(9, 4, 'to_person', 'to_person', 'number', 60, 0, '{\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"to_person\",\"sql_type\":\"int(11)\"}}', '2026-08-16 12:34:38'),
(10, 5, 'date_time', 'Date Time', 'datetime', 10, 0, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev\",\"column\":\"date_time\",\"sql_type\":\"datetime\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-17 12:24:21'),
(11, 4, 'to_ev_id', 'To Ev Id', 'number', 10, 0, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"to_ev_id\",\"sql_type\":\"int(10) unsigned\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-17 14:52:08'),
(12, 4, 'from_person', 'From Person', 'number', 50, 1, '{\"width\":\"100\",\"trim\":true,\"list_visible\":true,\"searchable\":true,\"filterable\":true,\"sortable\":true,\"table_binding\":{\"source_kind\":\"system\",\"table\":\"ed_ev_info\",\"column\":\"from_person\",\"sql_type\":\"int(11)\"},\"default_mode\":\"defined\",\"default_value\":\"\"}', '2026-08-17 14:52:08');




INSERT INTO `dataform_managed_tables` (`id`, `table_name`, `created_at`) VALUES
(1, 'ed_ev', '2026-08-24 12:37:26'),
(2, 'ed_ev_info', '2026-08-24 12:37:26'),
(3, 'ed_ev_person', '2026-08-24 12:37:26'),
(4, 'ed_ev_type', '2026-08-24 12:37:26');


INSERT INTO `dataform_records` (`id`, `dataform_id`, `data_json`, `created_at`, `updated_at`) VALUES
(3, 4, '{\"typ\":\"1\",\"date_time\":\"2026-08-19T12:00\",\"bemerkung\":\"testbemerkung\",\"to_basistabelle_events_id\":\"1\",\"to_person\":\"1\"}', '2026-08-16 12:35:35', '2026-08-16 12:35:35');

INSERT INTO `dataform_relations` (`id`, `name`, `relation_type`, `source_dataform_id`, `source_field_id`, `target_dataform_id`, `target_display_field_id`, `junction_name`, `lookup_field_id`, `is_required`, `is_enabled`, `configuration_json`, `created_at`, `updated_at`) VALUES
(3, 'ed_ev_id_to_ed_ev_info_id', '1:n', 5, NULL, 4, NULL, NULL, 11, 1, 1, '{\"semantics\":\"parent-child-v2\",\"parent_key\":\"id\",\"child_fk_field_id\":11,\"auto_form\":false,\"auto_physical\":false}', '2026-08-17 14:53:02', '2026-08-17 14:53:54'),
(4, 'ed_ev_info_typ_to_ed_ev_type', 'n:1', 4, 4, 4, NULL, NULL, NULL, 0, 1, '{\"semantics\":\"lookup-base-table-v1\",\"lookup_source_kind\":\"base_table\",\"source_fk_field_id\":4,\"base_table\":{\"table\":\"ed_ev_type\",\"key_column\":\"id\",\"display_column\":\"ev_type\"}}', '2026-08-18 14:12:49', '2026-08-18 17:34:28'),
(5, 'ed_ev_info_fromperson_to_ed_person_id', 'n:1', 4, 12, 4, NULL, NULL, NULL, 0, 1, '{\"semantics\":\"lookup-base-table-v1\",\"lookup_source_kind\":\"base_table\",\"source_fk_field_id\":12,\"base_table\":{\"table\":\"ed_ev_person\",\"key_column\":\"id\",\"display_column\":\"email\"}}', '2026-08-18 14:14:00', '2026-08-18 16:59:40'),
(6, 'ed_ev_info_toperson_to_ed_person_id', 'n:1', 4, 9, 4, NULL, NULL, NULL, 0, 1, '{\"semantics\":\"lookup-base-table-v1\",\"lookup_source_kind\":\"base_table\",\"source_fk_field_id\":9,\"base_table\":{\"table\":\"ed_ev_person\",\"key_column\":\"id\",\"display_column\":\"email\"}}', '2026-08-18 14:14:52', '2026-08-18 17:00:33');


INSERT INTO `dataform_table_bindings` (`id`, `dataform_id`, `source_kind`, `source_id`, `table_name`, `binding_mode`, `created_at`) VALUES
(1, 4, 'system', 0, 'ed_ev_info', 'schema', '2026-08-16 12:14:01'),
(2, 5, 'system', 0, 'ed_ev', 'schema', '2026-08-17 12:24:21');


INSERT INTO `dataforms` (`id`, `name`, `slug`, `description`, `status`, `table_save_mode`, `show_save_success`, `created_at`, `updated_at`) VALUES
(4, 'Ed Ev Info', 'ed-ev-info', 'Automatisch aus der Projekttabelle „ed_ev_info“ erzeugt.', 'draft', 'adhoc', 1, '2026-08-16 12:14:01', '2026-08-25 09:31:48'),
(5, 'Ed Ev', 'ed-ev', 'Automatisch aus der Projekttabelle „ed_ev“ erzeugt.', 'draft', 'manual', 1, '2026-08-17 12:24:21', '2026-08-17 12:24:21');

INSERT INTO `ed_ev` (`id`, `date_time`) VALUES
(9201, '2026-09-01 09:00:00'),
(9202, '2026-09-01 10:30:00'),
(9203, '2026-09-02 08:45:00'),
(9204, '2026-09-02 13:15:00'),
(9205, '2026-09-03 09:20:00'),
(9206, '2026-09-03 14:00:00'),
(9207, '2026-09-04 08:30:00'),
(9208, '2026-09-04 11:10:00'),
(9209, '2026-09-05 10:00:00'),
(9210, '2026-09-05 15:30:00'),
(9211, '2026-09-07 09:10:00'),
(9212, '2026-09-07 12:40:00'),
(9213, '2026-09-08 08:50:00'),
(9214, '2026-09-08 14:20:00'),
(9215, '2026-09-09 09:30:00'),
(9217, '2026-09-10 08:15:00'),
(9216, '2026-09-10 16:00:00'),
(9218, '2026-09-11 11:45:00'),
(9219, '2026-09-11 13:00:00'),
(9220, '2026-09-11 15:40:00');

INSERT INTO `ed_ev_info` (`id`, `to_ev_id`, `typ`, `date_time`, `bemerkung`, `from_person`, `to_person`) VALUES
(9301, 9201, 9101, '2026-09-01 09:00:00', 'Erstgespräch zum Vorgang; Ziele und nächste Schritte abgestimmt.', 9001, 9002),
(9302, 9201, 9108, '2026-09-01 09:20:00', 'Ergänzende Nachricht mit den vereinbarten Eckpunkten versendet.', 9002, 9001),
(9303, 9202, 9102, '2026-09-01 10:30:00', 'Telefonische Rückfrage zum aktuellen Bearbeitungsstand.', 9003, 9004),
(9304, 9203, 9104, '2026-09-02 08:45:00', 'Kurzes Abstimmungsmeeting mit Aufgabenverteilung.', 9005, 9006),
(9305, 9203, 9105, '2026-09-02 09:15:00', 'Folgeaufgabe aus dem Meeting an die zuständige Person übergeben.', 9006, 9007),
(9306, 9204, 9103, '2026-09-02 13:15:00', 'E-Mail mit ergänzenden Unterlagen und Rückmeldefrist gesendet.', 9008, 9009),
(9307, 9205, 9106, '2026-09-03 09:20:00', 'Termin für die nächste gemeinsame Abstimmung eingetragen.', 9010, 9011),
(9308, 9206, 9109, '2026-09-03 14:00:00', 'Neues Dokument zum Vorgang abgelegt und zur Prüfung bereitgestellt.', 9012, 9013),
(9309, 9206, 9116, '2026-09-03 14:25:00', 'Dokument formal geprüft; zwei kleinere Rückfragen sind offen.', 9013, 9012),
(9310, 9207, 9107, '2026-09-04 08:30:00', 'Rückruf vereinbart, da die Zielperson zunächst nicht erreichbar war.', 9014, 9015),
(9311, 9208, 9110, '2026-09-04 11:10:00', 'Entscheidung nach Rücksprache dokumentiert und freigegeben.', 9016, 9017),
(9312, 9209, 9111, '2026-09-05 10:00:00', 'Status des Vorgangs von offen auf in Bearbeitung geändert.', 9018, 9019),
(9313, 9209, 9112, '2026-09-05 10:10:00', 'Erinnerung für die noch ausstehende Rückmeldung gesetzt.', 9019, 9018),
(9314, 9210, 9113, '2026-09-05 15:30:00', 'Vor-Ort-Termin durchgeführt; Sachstand gemeinsam aufgenommen.', 9020, 9001),
(9315, 9211, 9114, '2026-09-07 09:10:00', 'Beratung zu den möglichen nächsten Verfahrensschritten durchgeführt.', 9002, 9005),
(9316, 9212, 9115, '2026-09-07 12:40:00', 'Vorgang mit allen bisher vorliegenden Informationen übergeben.', 9006, 9010),
(9317, 9213, 9117, '2026-09-08 08:50:00', 'Zwischenergebnis fachlich freigegeben.', 9011, 9014),
(9318, 9213, 9119, '2026-09-08 09:05:00', 'Interne Notiz zur Freigabe und zu den verbleibenden Restpunkten ergänzt.', 9014, 9011),
(9319, 9214, 9118, '2026-09-08 14:20:00', 'Vorgang wegen überschrittener Rückmeldefrist eskaliert.', 9015, 9018),
(9320, 9215, 9120, '2026-09-09 09:30:00', 'Sonstiger Vorgang zur Prüfung der allgemeinen Erfassungsfunktion.', 9019, 9020),
(9321, 9219, 9110, '2026-08-20 07:27:00', 'Restore-Test erfolgreich', 9005, 0),
(9322, 9220, 9110, '2026-08-12 07:31:00', 'testbemerkung neu', 9005, 9013),
(9323, 9211, 9102, '2026-08-27 22:00:00', 'test35', 9017, 9018),
(9324, 9219, 9101, '2026-08-28 11:56:00', 'testbemerkung4', 9014, 9014);

INSERT INTO `ed_ev_person` (`id`, `saturation`, `email`, `firstname`, `lastname`) VALUES
(9001, 1, NULL, '101', '201'),
(9002, 2, NULL, '102', '202'),
(9003, 1, NULL, '103', '203'),
(9004, 2, NULL, '104', '204'),
(9005, 1, NULL, '105', '205'),
(9006, 2, NULL, '106', '206'),
(9007, 3, NULL, '107', '207'),
(9008, 1, NULL, '108', '208'),
(9009, 2, NULL, '109', '209'),
(9010, 1, NULL, '110', '210'),
(9011, 2, NULL, '111', '211'),
(9012, 1, NULL, '112', '212'),
(9013, 3, NULL, '113', '213'),
(9014, 2, NULL, '114', '214'),
(9015, 1, NULL, '115', '215'),
(9016, 2, NULL, '116', '216'),
(9017, 1, NULL, '117', '217'),
(9018, 2, NULL, '118', '218'),
(9019, 3, NULL, '119', '219'),
(9020, 1, NULL, '120', '220');

INSERT INTO `ed_ev_type` (`id`, `ev_type`) VALUES
(9105, 'Aufgabe'),
(9114, 'Beratung'),
(9113, 'Besuch'),
(9109, 'Dokument'),
(9103, 'E-Mail'),
(9110, 'Entscheidung'),
(9112, 'Erinnerung'),
(9118, 'Eskalation'),
(9117, 'Freigabe'),
(9101, 'Gespräch'),
(9104, 'Meeting'),
(9108, 'Nachricht'),
(9119, 'Notiz'),
(9116, 'Prüfung'),
(9107, 'Rückruf'),
(9120, 'Sonstiges'),
(9111, 'Statusänderung'),
(9102, 'Telefonat'),
(9106, 'Termin'),
(9115, 'Übergabe');

INSERT INTO `migrations` (`id`, `migration`, `checksum`, `executed_at`) VALUES
(1, '001_migrations.php', 'ad096de26556296667dd203af6823bdd43355bafd422741f8f15f9ee54c284c4', '2026-08-24 12:32:03'),
(3, '002_dataforms.php', '6715931de35fd9feb065822459e994e8128ebd56d0920bb91fb43f00612745a2', '2026-08-24 12:32:03'),
(4, '003_data_sources.php', '6cc3abc8dfb24d66ceb53bb34763fbdc424b86803628ce163a43334e91a5ea6b', '2026-08-24 12:32:03'),
(5, '004_table_workspace.php', 'a15c693c079263ed84b00549fb6d11a850bebceaf9254e44aa89ef8eaf054fe8', '2026-08-24 12:32:03'),
(6, '005_dataform_table_bindings.php', '43544f5b3792a0a472ae69d6efe00090536680abd58e3de148e77e19ee9a3d1d', '2026-08-24 12:32:03');

INSERT INTO `project_package_history` (`id`, `package_id`, `project_name`, `package_name`, `package_version`, `action_name`, `file_name`, `sha256`, `status`, `details_json`, `user_id`, `created_at`) VALUES
(1, '4aed956c9f7e37f68d7e84fef71ba49b', 'Testprojekt 63', 'ed_ev_demo', '1.1.0', 'import', 'ed_ev_demo-1.1.0-20260823_130955.dfpkg', '1137eefc4679508856dd9f87ca041f28ae73a20cba9c4c5b0f48bf82d4a3979c', 'success', '{\n    \"inserted\": 97,\n    \"updated\": 0,\n    \"skipped\": 0,\n    \"tables\": {\n        \"dataforms\": {\n            \"inserted\": 2,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_fields\": {\n            \"inserted\": 7,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_table_bindings\": {\n            \"inserted\": 2,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_relations\": {\n            \"inserted\": 4,\n            \"updated\": 0,\n            \"skipped\": 0\n        }\n    },\n    \"schemas\": {\n        \"created\": 4,\n        \"existing\": 0\n    },\n    \"physical_records\": {\n        \"ed_ev\": {\n            \"inserted\": 20,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"ed_ev_info\": {\n            \"inserted\": 22,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"ed_ev_person\": {\n            \"inserted\": 20,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"ed_ev_type\": {\n            \"inserted\": 20,\n            \"updated\": 0,\n            \"skipped\": 0\n        }\n    }\n}', 1, '2026-08-24 12:37:27'),
(2, 'a467ca85a35948f0e54ffceebb93441e', 'Import_ev_data', 'Import_ev_data', '1.1.0', 'export', 'import-ev-data-1.1.0-20260824_121002.dfpkg', 'e50d88082ca79c6d8d66bc58af91b7c4c1f6bd5d2a03f2e115447198537dd792', 'success', '{\n    \"selection\": {\n        \"dataformIds\": [\n            5,\n            4\n        ],\n        \"physicalTables\": [\n            \"ed_ev\",\n            \"ed_ev_info\",\n            \"ed_ev_person\",\n            \"ed_ev_type\"\n        ],\n        \"autoIncludedTables\": [\n            \"ed_ev_info\",\n            \"ed_ev\",\n            \"ed_ev_type\",\n            \"ed_ev_person\"\n        ]\n    },\n    \"counts\": {\n        \"configuration\": {\n            \"dataforms\": 2,\n            \"dataform_fields\": 7,\n            \"dataform_relations\": 4,\n            \"dataform_table_bindings\": 2\n        },\n        \"schemas\": 4,\n        \"physicalRecords\": []\n    }\n}', 1, '2026-08-24 14:10:02'),
(3, 'cee4c4f450c633fd96b673a5bf70bcea', 'Testprojekt 63', 'ed_ev_demo', '1.1.0', 'import', 'ed_ev_demo-1.1.0-20260823_102224.dfpkg', '219d69ae70a069699e943a7b9f98b8aa26b00ddb997ec0a9dbe5466b804bb9ef', 'success', '{\n    \"inserted\": 1,\n    \"updated\": 97,\n    \"skipped\": 0,\n    \"tables\": {\n        \"dataforms\": {\n            \"inserted\": 0,\n            \"updated\": 2,\n            \"skipped\": 0\n        },\n        \"dataform_fields\": {\n            \"inserted\": 0,\n            \"updated\": 7,\n            \"skipped\": 0\n        },\n        \"dataform_table_bindings\": {\n            \"inserted\": 0,\n            \"updated\": 2,\n            \"skipped\": 0\n        },\n        \"dataform_layout_nodes\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_behaviors\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_versions\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_queries\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_list_settings\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_saved_filters\": {\n            \"inserted\": 0,\n            \"updated\": 0,\n            \"skipped\": 0\n        },\n        \"dataform_relations\": {\n            \"inserted\": 0,\n            \"updated\": 4,\n            \"skipped\": 0\n        },\n        \"dataform_records\": {\n            \"inserted\": 1,\n            \"updated\": 0,\n            \"skipped\": 0\n        }\n    },\n    \"schemas\": {\n        \"created\": 0,\n        \"existing\": 4\n    },\n    \"physical_records\": {\n        \"ed_ev\": {\n            \"inserted\": 0,\n            \"updated\": 20,\n            \"skipped\": 0\n        },\n        \"ed_ev_info\": {\n            \"inserted\": 0,\n            \"updated\": 22,\n            \"skipped\": 0\n        },\n        \"ed_ev_person\": {\n            \"inserted\": 0,\n            \"updated\": 20,\n            \"skipped\": 0\n        },\n        \"ed_ev_type\": {\n            \"inserted\": 0,\n            \"updated\": 20,\n            \"skipped\": 0\n        }\n    }\n}', 1, '2026-08-24 14:53:12');

SET FOREIGN_KEY_CHECKS=1;
