easyIT DataForm HTML5-Anwendung
==============================

Projekt: Import_ev_data
DataForms: 2

Installation:
1. ZIP in einen Webserverordner entpacken.
2. setup.php im Browser öffnen.
3. MySQL/MariaDB-Zugangsdaten eingeben.
4. Der enthaltene Datenbanksnapshot wird importiert und config.php erzeugt.
5. Danach index.php öffnen.

Das Paket enthält ausschließlich die Projekt-Runtime, DataForm-Seiten, erforderliche Bilder/Assets, Projektmedien und den Datenbanksnapshot. easyIT Enterprise ist nicht enthalten.
