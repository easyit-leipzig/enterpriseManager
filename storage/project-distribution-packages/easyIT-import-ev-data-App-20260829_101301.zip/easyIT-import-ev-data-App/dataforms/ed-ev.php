<?php
declare(strict_types=1);
require __DIR__.'/../lib/DataFormApp.php';
df_render_dataform(5);
